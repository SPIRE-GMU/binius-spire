.. cmake-module:: ../../rapids-cmake/export/write_dependencies.cmake
