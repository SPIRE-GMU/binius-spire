.. cmake-module:: ../../rapids-cmake/cuda/patch_toolkit.cmake
