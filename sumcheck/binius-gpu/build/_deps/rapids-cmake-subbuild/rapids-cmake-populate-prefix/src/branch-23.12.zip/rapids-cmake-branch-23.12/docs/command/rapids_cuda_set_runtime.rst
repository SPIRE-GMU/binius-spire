.. cmake-module:: ../../rapids-cmake/cuda/set_runtime.cmake
