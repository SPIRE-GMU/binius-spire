.. cmake-module:: ../../rapids-cmake/test/gpu_requirements.cmake
