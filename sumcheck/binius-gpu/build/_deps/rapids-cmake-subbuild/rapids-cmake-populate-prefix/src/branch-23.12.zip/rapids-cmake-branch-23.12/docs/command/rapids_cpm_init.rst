.. cmake-module:: ../../rapids-cmake/cpm/init.cmake
