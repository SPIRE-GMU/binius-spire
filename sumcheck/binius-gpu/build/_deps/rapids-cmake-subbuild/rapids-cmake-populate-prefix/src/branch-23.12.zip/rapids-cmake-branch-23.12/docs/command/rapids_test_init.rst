.. cmake-module:: ../../rapids-cmake/test/init.cmake
