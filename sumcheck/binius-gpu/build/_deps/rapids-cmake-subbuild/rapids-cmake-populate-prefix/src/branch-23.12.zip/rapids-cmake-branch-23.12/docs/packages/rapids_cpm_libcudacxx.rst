.. cmake-module:: ../../rapids-cmake/cpm/libcudacxx.cmake
